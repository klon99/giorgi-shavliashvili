package com.example.myapplication2;

public class car {
    private String model;
    private String manufacturer;
    private int doi;

    public car(String Model, String Manufacturer, int Doi){
        model = Model;
        manufacturer= Manufacturer;
        doi = Doi;
    }
}
